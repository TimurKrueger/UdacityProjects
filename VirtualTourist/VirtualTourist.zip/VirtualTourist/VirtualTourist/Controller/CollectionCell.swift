//
//  CollectionCell.swift
//  VirtualTourist
//
//  Created by Timur Krüger on 07.06.20.
//  Copyright © 2020 Timur. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}
